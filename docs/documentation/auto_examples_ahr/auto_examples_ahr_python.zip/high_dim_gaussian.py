"""
TODO add make_classification example

========================================
Example: Approximate hubness reduction
========================================

This example shows how to combine approximate nearest neighbor search and hubness reduction.

"""